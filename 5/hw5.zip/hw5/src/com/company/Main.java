package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Parallelogram p = new Parallelogram(new Vector(1,-2,5),new Vector(0,-2,1));
        Parallelogram p2 = new Parallelogram(new Point(1,7,0), new Point(4,3,0), new Point(1,9,0));
        System.out.println(p.square());
        System.out.println(p2.square());
        Parallelepiped pd1 = new Parallelepiped(p2,3);
        Parallelepiped pd2 = new Parallelepiped(p2,3, 90);
        System.out.println(pd1.volume());
        System.out.println(pd2.volume());
    }
}
