package com.company;

public interface IServiceFactory {
    IService getService();
}
