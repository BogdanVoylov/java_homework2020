package com.company;

public interface IService {
    void fixWheels();
    void fixEngine();
    void fixElectronics();
}
