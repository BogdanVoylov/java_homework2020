package com.company;

public enum FuelType {
    OR87, OR89, OR92, Electricity
}
