package com.company;

public interface IAmphibian {
    public abstract String pressurization();
    public abstract String depressurization();
}
