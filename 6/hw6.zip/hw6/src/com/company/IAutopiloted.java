package com.company;

public interface IAutopiloted {
    public abstract String turnOnAutopilot();
    public abstract String turnOffAutopilot();
}
