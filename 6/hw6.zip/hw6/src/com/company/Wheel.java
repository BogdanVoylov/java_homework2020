package com.company;

public class Wheel extends Detail {
    public Wheel(Car owner){
        super(owner);
    }
}
