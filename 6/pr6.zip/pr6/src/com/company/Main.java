package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Circle circle = new Circle(new Point(0,0),new Point(1,1));
        System.out.println(circle);
        System.out.println("Circle square "+circle.square());
        System.out.println("Circle border length "+circle.borderLength());

        Tetragon tetragon = new Tetragon(new Point(0,0), new Point(0,1), new Point(1,1), new Point(1,0));
        System.out.println(tetragon);
        System.out.println("Tetragon square "+tetragon.square());
        System.out.println("Tetragon border length "+tetragon.borderLength());

        Triangle triangle = new Triangle(new Point(0,0), new Point(0,1), new Point(1,0));
        System.out.println(triangle);
        System.out.println("Triangle square "+triangle.square());
        System.out.println("Triangle border length "+triangle.borderLength());

        Rectangle rectangle = null;
        try {
            rectangle = new Rectangle(new Point(0,0), new Point(0,1), new Point(1,1), new Point(1,0));
        } catch (Exception e) {
            System.out.println("Not rectangle");
            return;
        }
        System.out.println(rectangle);
        System.out.println("Rectangle square "+rectangle.square());
        System.out.println("Rectangle border length "+rectangle.borderLength());
    }
}
