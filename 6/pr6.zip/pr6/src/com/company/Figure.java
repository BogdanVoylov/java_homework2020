package com.company;

abstract public class Figure {
    protected Point[] points;
    public abstract double square();
    public abstract double borderLength();
}
